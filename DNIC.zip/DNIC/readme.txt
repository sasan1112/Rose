This readme file was generated on 2023-06-22.
1. Reproducibility Criteria Answers: This readme contains answers to the reproducibility criteria that are relevant to our study and notes regarding which criteria are not relevant.
2. Zip file: DNIC.zip 
    This file details the contents of the accompanying zip file.

GENERAL INFORMATION
Answers to reproducibility criteria requirements below contain pointers to where this information can be found where applicable.

REPRODUCIBILITY CRITERIA (as stated at https://2023.emnlp.org/calls/main_conference_papers/#reproducibility-criteria) 
I. Section 1 Experimental Results
1) Requirement: A clear description of the mathematical setting, algorithm, and/or model
Our Answer: Included in Sec. 4.1 is the Weight of Evidence equation, in Sec. 5.3 we describe our mathematical equation which is the basis for our approach for using linear mixed effects models. We utilize R statistical software packages for our logistic and linear mixed effects regression models, which are detailed in Appendix C (see "Execution of our models" for the libraries we used and "Models" for model details in particular).
2) Requirement: Submission of a zip file
Our Answer: Yes, the zip file name is: DNIC.zip
a. Containing source code: N/A 
b. Specification of all dependencies, including external libraries, or a link to such resources (while still anonymized) 
Our answer: See Sec. 5.1 of the report submission, footnotes 4,5,6, and 7 provide the translation API URLs for the MT systems we used (Google Cloud Translate, Microsoft Text Translator, Marian MT). We also reference our usage of the pre-existing Sacrebleu package to compute BLEU ((Post, 2018) citation and footnote 8) in Sec. 5.2.
3) Requirement: Description of computing infrastructure used: 
The average runtime for each model or algorithm (e.g., training, inference, etc.), or estimated energy cost: N/A
    Number of parameters in each model: N/A
    Corresponding validation performance for each reported test result: N/A
    Explanation of evaluation metrics used, with links to code:
    Our answer: For evaluation metrics, we used the Sacrebleu package to compute BLEU (((Post, 2018), and footnote 8). See our description of our evaluation approach in Section 5, with our evaluation metrics described in Section 5.2.
II. Section 2: For all experiments with hyperparameter search: N/A
III. Section 3: 
For all datasets used:
    Relevant details such as languages, number of examples, and label distributions
    Our Answer: See Section 4 for details of our dataset and translation languages.
    Details of train/validation/test splits: N/A
    Explanation of any data that were excluded, and all pre-processing steps: 
    Our Answer: See section 4.1 for the filtering based on the Weight of Evidence values. 
    A zip file containing data or a link to a downloadable version of the data: See DNIC.zip.
    For new data collected, a complete description of the data collection process, such as instructions to annotators and methods for quality control.
    Our answer: See section 4.1 for a description of our names list and section 4.2 for our template data collection details.

ZIP FILE CONTENTS AND DATA OVERVIEW
Contents of DNIC.zip file:
1) File: DNIC_filtered_by_WoE.tsv
Description: This is the final Diverse Names in Context dataset ultimately used for evaluation.
Format: Text file with tabs separating fields
Fields list:
Name    
Gender  
Race/Ethnicity  
Machine Translation System  
Translation Back Translation    
Translation Language    
Template Number
2) 
File: baby_names_w_templates.tsv
Description: This is the original baby names list as well as English sentences we created based on templates plus names.
Format: Text file with tabs separating fields
Fields list:
Birth Year  
Gender  
Race/Ethnicity  
Name    
Number of Babies    
Rank    
Sentence 1  
Sentence 2  
Sentence 3  
Sentence 4  
Sentence 5  
Sentence 6  
Sentence 7  
Sentence 8  
Sentence 9  
Sentence 10 
Sentence 11 
Sentence 12 
Sentence 13 
Sentence 14 
Sentence 15 
Sentence 16
